﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RM.Model
{
    public partial class frmDashboard : Form
    {

        // Connection string for your database
        private string connectionString = "Data Source=LAPTOP-AHHL9HD4;Initial Catalog=RM;User ID=ro;Password=ro123;";

        public frmDashboard()
        {
            InitializeComponent();
        }
     


       
       

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            UpdateDashboard();
        }

        private void UpdateDashboard()
        {
            try
            {
                // Establish a connection to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Retrieve total sales amount
                    decimal totalSalesAmount = GetTotalSalesAmount(connection);
                    lblTotal.Text = "Rs." + totalSalesAmount.ToString();

                    // Retrieve daily sales amount
                    decimal dailySalesAmount = GetDailySalesAmount(connection);
                    lblDaily.Text = "Rs." + dailySalesAmount.ToString();

                    // Retrieve total products available
                    int totalProducts = GetTotalProducts(connection);
                    lblProduct.Text = totalProducts.ToString();

                    // Retrieve total categories available
                    int totalCategories = GetTotalCategories(connection);
                    lblCate.Text = totalCategories.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating the dashboard: " + ex.Message);
            }
        }

        private decimal GetTotalSalesAmount(SqlConnection connection)
        {
            string query = "SELECT SUM(total) FROM tblMain";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                object result = command.ExecuteScalar();
                if (result != DBNull.Value)
                    return Convert.ToDecimal(result);
                else
                    return 0m; // or any other default value you prefer
            }
        }

        private decimal GetDailySalesAmount(SqlConnection connection)
        {
            string query = "SELECT SUM(total) FROM tblMain WHERE aDate = @date";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@date", DateTime.Today);
                object result = command.ExecuteScalar();
                if (result != DBNull.Value)
                    return Convert.ToDecimal(result);
                else
                    return 0m; // or any other default value you prefer
            }
        }

        private int GetTotalProducts(SqlConnection connection)
        {
            string query = "SELECT COUNT(*) FROM products";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                object result = command.ExecuteScalar();
                if (result != DBNull.Value)
                    return Convert.ToInt32(result);
                else
                    return 0; // or any other default value you prefer
            }
        }

        private int GetTotalCategories(SqlConnection connection)
        {
            string query = "SELECT COUNT(*) FROM category";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                object result = command.ExecuteScalar();
                if (result != DBNull.Value)
                    return Convert.ToInt32(result);
                else
                    return 0; // or any other default value you prefer
            }
        }


        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }
    }




}



