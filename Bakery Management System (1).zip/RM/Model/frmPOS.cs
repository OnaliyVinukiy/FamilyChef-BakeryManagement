﻿            using Guna.UI2.WinForms;
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing; 
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using RM.Model;
using System.Windows.Controls;
using System.Drawing.Printing;
using System.Data.SqlTypes;

namespace RM.Model
{
    public partial class frmPOS : Form
    {
        public frmPOS()
        {
            InitializeComponent();
        }

        public int MainID =0;
        public string OrderType = "";
        public string customerName = "";
        public string customerPhone = "";
        public string customerAddress = "";

        public int DriverID = 0;

          

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmPOS_Load(object sender, EventArgs e)
        {
            guna2DataGridView1.BorderStyle = BorderStyle.FixedSingle;
            AddCategory();
            productPanel.Controls.Clear();
            txtcusphone.Visible = false;
            txtdrivername.Visible = false;
            lblcusname.Visible = false;
            txtCusAdd.Visible = false;
        }

        private void AddCategory()
        {
            string query = "Select * from Category";
            SqlCommand cmd = new SqlCommand(query, MainClass.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CategoryPanel.Controls.Clear();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    Guna.UI2.WinForms.Guna2Button b = new Guna.UI2.WinForms.Guna2Button();
                    b.FillColor = Color.FromArgb(0, 128, 128);
                    b.Size = new Size(201, 62);
                    b.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
                    b.Text = row["catName"].ToString();
                    b.Tag = row["catID"]; // Store the category ID in the Tag property

                    // Event handler for click
                    b.Click += new EventHandler(b_Click);
                    CategoryPanel.Controls.Add(b);
                }
            }
        }


        private void AddItems(string id, string proID,string name, string cat, string price, System.Drawing.Image pImage)
        {
            var w = new UserProduct()
            {
                pName = name,
                pPrice = price,
                pCategory = cat,
                PImage = pImage,
                id = Convert.ToInt32(proID)
            };
            productPanel.Controls.Add(w);
            w.onSelect += (ss, ee) =>
            {
                var wdg = (UserProduct)ss;

                foreach (DataGridViewRow item in guna2DataGridView1.Rows)
                {
                    //this will check whether product is already there then add one to quantity and update price
                    if (Convert.ToInt32(item.Cells["dgvproID"].Value) == wdg.id)
                    {
                        item.Cells["dgvQty"].Value = (int.Parse(item.Cells["dgvQty"].Value.ToString()) + 1);
                        item.Cells["dgvAmount"].Value = int.Parse(item.Cells["dgvQty"].Value.ToString()) *
                                                        double.Parse(item.Cells["dgvPrice"].Value.ToString());
                        GetTotal();
                        return;
                    }
                }
                //this line add new product, first 0 for sr# and second 0 for id
                guna2DataGridView1.Rows.Add(new object[] { 0,0, wdg.id, wdg.pName, 1, wdg.pPrice, wdg.pPrice });
                GetTotal();
            };

            // Add event handler for CellValueChanged event
            guna2DataGridView1.CellValueChanged += (s, e) =>
            {
                if (e.ColumnIndex == guna2DataGridView1.Columns["dgvQty"].Index)
                {
                    var qty = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["dgvQty"].Value);
                    var pri = Convert.ToDouble(guna2DataGridView1.Rows[e.RowIndex].Cells["dgvPrice"].Value);
                    guna2DataGridView1.Rows[e.RowIndex].Cells["dgvAmount"].Value = qty * pri;
                    GetTotal();
                }
            };
        }

        //getting product from database
        private void LoadProductsByCategory(int categoryId)
        {
            string query = "SELECT * FROM products INNER JOIN category ON catID = CategoryID WHERE catID = @categoryId";
            SqlCommand cmd = new SqlCommand(query, MainClass.con);
            cmd.Parameters.AddWithValue("@categoryId", categoryId);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow item in dt.Rows)
            {
                byte[] imageArray = (byte[])item["pImage"];
                byte[] imageByteArray = imageArray;

                // Save the image to a specific folder
                string saveFolderPath = @"C:\Users\Onaliy Vinukiy\OneDrive - NSBM\First Year\Third Sem\C#\C# Project\C-Project\RM\RM\Resources"; // Specify the folder path where images are stored

                string imageName = "image_" + item["pID"].ToString() + ".jpg"; // Use the product ID as the image name

                if (!Directory.Exists(saveFolderPath))
                    Directory.CreateDirectory(saveFolderPath);

                string imagePath = Path.Combine(saveFolderPath, imageName);

                File.WriteAllBytes(imagePath, imageArray);

                // Add the item with the image path to your display method
                AddItems("0", item["pID"].ToString(), item["pName"].ToString(), item["catName"].ToString(), item["pPrice"].ToString(), System.Drawing.Image.FromFile(imagePath));
            }
        }






        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            foreach (var item in productPanel.Controls)
            {
                var pro =(UserProduct)item;
                pro.Visible = pro.pName.ToLower().Contains(txtSearch.Text.Trim().ToLower());
            }
        }

        private void guna2DataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            int count = 0;
            foreach (DataGridViewRow row in guna2DataGridView1.Rows)
            {
                count++;
                row.Cells[0].Value = count;
            }
        }

        private void GetTotal()
        {
            double tot = 0;
            lbltotal1.Text = "";
            foreach (DataGridViewRow item in guna2DataGridView1.Rows)
            {
                tot += double.Parse(item.Cells["dgvAmount"].Value.ToString());
            }
            lbltotal1.Text = tot.ToString("N2");
        }
        private void b_Click(object sender, EventArgs e)
        {
            Guna.UI2.WinForms.Guna2Button categoryButton = (Guna.UI2.WinForms.Guna2Button)sender;
            int categoryId = (int)categoryButton.Tag; // Retrieve the category ID

            productPanel.Controls.Clear();
            LoadProductsByCategory(categoryId);
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            guna2DataGridView1.Rows.Clear();
            MainID = 0;
            lbltotal1.Text = "00.00";
            txtchange.Text= string.Empty;
            received.Text = string.Empty;
            txtdrivername.Text=string.Empty;
            txtCusAdd.Text = string.Empty;
            txtcusphone.Text = string.Empty;
            lblcusname.Text = string.Empty;
        }

        public void btnDelivery_Click(object sender, EventArgs e)
        {
            OrderType = "Delivery";
            frmAddCustomer frm = new frmAddCustomer();
            frm.MainID = MainID;
            frm.OrderType=OrderType;
            MainClass.BlurBackground(frm);
            if (frm.DriverID>0)
            {
                DriverID = frm.DriverID;
                lblcusname.Text = "Customer Name: " + frm.txtName.Text; 
                txtcusphone.Text = "Phone: " + frm.txtPhone.Text;
                txtCusAdd.Text = "Address: " + frm.txtAddress.Text;
                txtdrivername.Text= "Driver: " + frm.cbDriver.Text;
                txtcusphone.Visible = true;
                txtdrivername.Visible = true;
                lblcusname.Visible = true;
                txtCusAdd.Visible = true;
                customerName = frm.txtName.Text;
                customerPhone = frm.txtPhone.Text;
            }

        }

        public void btnTake_Click(object sender, EventArgs e)
        {
            OrderType = "Take Away";
            txtcusphone.Visible = false;
            txtdrivername.Visible = false;
            lblcusname.Visible = false;
            txtCusAdd.Visible = false;
        }

        public void btnDine_Click(object sender, EventArgs e)
        {

            OrderType = "Dine In";
            txtcusphone.Visible = false;
            txtdrivername.Visible = false;
            lblcusname.Visible = false;
            txtCusAdd.Visible = false;
        }

        private void btnKot_Click(object sender, EventArgs e)
        {
            //save the data in database 
            string query1 = ""; //main table
            string query2 = ""; //details table

            int detailID = 0;
            if (OrderType == "")
            {
                guna2MessageDialog1.Show("Please select Order Type");
                return;
            }
            if (MainID == 0) //insert
            {
                query1 = @"Insert into tblMain Values(@aDate,@aTime,@status,@OrderType,@total,@received,@change,@DriverID,@CustName,@CustPhone,@CustAddress);
        Select SCOPE_IDENTITY()";
                //this line will get recent @id values
            }
            else //update
            {
                query1 = @"Update tblMain Set status=@status, total=@total,received=@received,change=@change where MainID=@Id";
            }

            SqlCommand cmd = new SqlCommand(query1, MainClass.con);
            cmd.Parameters.AddWithValue("@Id", MainID); // add parameter for ID
            cmd.Parameters.AddWithValue("@aDate", DateTime.Now.Date); // remove unnecessary conversion
            cmd.Parameters.AddWithValue("@aTime", DateTime.Now.ToShortTimeString());
            cmd.Parameters.AddWithValue("@status", "Paid");
            cmd.Parameters.AddWithValue("@OrderType", OrderType);
            cmd.Parameters.AddWithValue("@total", Convert.ToDouble(lbltotal1.Text));
            cmd.Parameters.AddWithValue("@received", Convert.ToDouble(received.Text));
            cmd.Parameters.AddWithValue("@change", Convert.ToDouble(txtchange.Text));
            cmd.Parameters.AddWithValue("@DriverID", DriverID);
            cmd.Parameters.AddWithValue("@CustName", customerName);
            cmd.Parameters.AddWithValue("@CustPhone", customerPhone);
            cmd.Parameters.AddWithValue("@CustAddress", customerAddress);

            if (MainClass.con.State == ConnectionState.Closed) { MainClass.con.Open(); }
            if (MainID == 0) { MainID = Convert.ToInt32(cmd.ExecuteScalar()); } else { cmd.ExecuteNonQuery(); }
            if (MainClass.con.State == ConnectionState.Open) { MainClass.con.Close(); }

            foreach (DataGridViewRow row in guna2DataGridView1.Rows)
            {
                detailID = Convert.ToInt32(row.Cells["dgvId"].Value);
                if (detailID == 0) //insert
                {
                    query2 = @"Insert into tblDetails Values (@MainID,@proID,@qty,@price,@amount)";
                }
                else//update
                {
                    query2 = @"Update tblDetails Set proID= @proID,qty=@qty,price= @price,amount= @amount where DetailID=@ID";
                }
                SqlCommand cmd2 = new SqlCommand(query2, MainClass.con);
                cmd2.Parameters.AddWithValue("@ID", detailID);
                cmd2.Parameters.AddWithValue("@MainID", MainID);
                cmd2.Parameters.AddWithValue("@proID", Convert.ToInt32(row.Cells["dgvproID"].Value));
                cmd2.Parameters.AddWithValue("@qty", Convert.ToInt32(row.Cells["dgvQty"].Value));
                cmd2.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells["dgvPrice"].Value));
                cmd2.Parameters.AddWithValue("@amount", Convert.ToDouble(row.Cells["dgvAmount"].Value));
                if (MainClass.con.State == ConnectionState.Closed) { MainClass.con.Open(); }

                cmd2.ExecuteNonQuery();
            }

            if (MainClass.con.State == ConnectionState.Open) { MainClass.con.Close(); }

        


                guna2MessageDialog1.Show("Saved Successfully");
                MainID = 0;
                detailID = 0;
            txtcusphone.Text = "";
            txtdrivername.Text = "";
            lblcusname.Text = "";
            txtCusAdd.Text = "";

        }
        public int id = 0;
        private void btnBill_Click(object sender, EventArgs e)
        {
            
            frmBillList frm = new frmBillList();
            MainClass.BlurBackground(frm);
            if (frm.MainID>0)
            {
                id=frm.MainID;
                LoadEntries();
            }
        }
        private void LoadEntries()
        {
            string query = @"SELECT * FROM tblMain m 
            INNER JOIN tblDetails d ON m.MainID = d.MainID 
            INNER JOIN products p ON p.pID = d.proID 
            WHERE m.MainID = @id";
            SqlCommand cmd2 = new SqlCommand(query, MainClass.con);
            cmd2.Parameters.AddWithValue("@id", id);
            DataTable dt2 = new DataTable();
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            da2.Fill(dt2);

            if (dt2.Rows[0]["OrderType"].ToString()=="Delivery")
            {
                btnDelivery.Checked = true;
            }

            else if (dt2.Rows[0]["OrderType"].ToString() == "Take Away")
            {
                btnTake.Checked = true;
            }
            else
            {
                btnDine.Checked = true;
            }


                guna2DataGridView1.Rows.Clear();

            foreach (DataRow item in dt2.Rows)
            {

                string DetailID = item["DetailID"].ToString();
                string proID = item["proID"].ToString();
                string proName = item["pName"].ToString();
                string qty = item["qty"].ToString();
                string price = item["price"].ToString();
                string amount = item["amount"].ToString();

                object[] obj = { 0, DetailID, proID,proName, qty, price, amount };
                guna2DataGridView1.Rows.Add(obj);
            }
            GetTotal();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {


            int detailID = 0;
            string query2 = "";
          
            
               string query = @"Update tblMain set status='Paid', total=@total, received=@rec, change=@change where MainID = @id";
              

            Hashtable ht = new Hashtable();
            ht.Add("@id", id);
            ht.Add("@total", double.Parse(lbltotal1.Text));
            ht.Add("@rec", received.Text);
           
            ht.Add("@change",  txtchange.Text);
            ht.Add("@date", DateTime.Now.Date);
            ht.Add("@time", DateTime.Now.ToShortTimeString());
            ht.Add("@ordertype", OrderType);
            foreach (DataGridViewRow row in guna2DataGridView1.Rows)
            {
                detailID = Convert.ToInt32(row.Cells["dgvId"].Value);
               
                    query2 = @"Update tblDetails Set proID= @proID,qty=@qty,price= @price,amount= @amount where DetailID=@ID";
                
                SqlCommand cmd2 = new SqlCommand(query2, MainClass.con);
                cmd2.Parameters.AddWithValue("@ID", detailID);
                cmd2.Parameters.AddWithValue("@MainID", id);
                cmd2.Parameters.AddWithValue("@proID", Convert.ToInt32(row.Cells["dgvproID"].Value));
                cmd2.Parameters.AddWithValue("@qty", Convert.ToInt32(row.Cells["dgvQty"].Value));
                cmd2.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells["dgvPrice"].Value));
                cmd2.Parameters.AddWithValue("@amount", Convert.ToDouble(row.Cells["dgvAmount"].Value));
                if (MainClass.con.State == ConnectionState.Closed) { MainClass.con.Open(); }

                cmd2.ExecuteNonQuery();
            }
            if (MainClass.SQL(query, ht) > 0)
            {
                guna2MessageDialog1.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
                guna2MessageDialog1.Show("Saved Successfully");

            }
        }

      



       
        public double amt;
     
        private void received_TextChanged(object sender, EventArgs e)
        {
            double amt = 0;
            double receipt = 0;
            double change = 0;
            double.TryParse(lbltotal1.Text, out amt);
            double.TryParse(received.Text, out receipt);
            lbltotal1.Text = amt.ToString();

            change = Math.Abs(amt - receipt);
            txtchange.Text = change.ToString();
        }

       
        private void doc_PrintPage(object sender, PrintPageEventArgs e)
        {
           
   
            Font printFont = new Font("Courier New", 8); // Use a monospaced font
            float yPos = 10; // Adjust the initial vertical position
            float leftMargin = 10; // Adjust the left margin
           

            e.Graphics.DrawString("Family Chef Bakehouse", printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
            e.Graphics.DrawString("Panadura", printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
          
            e.Graphics.DrawString("Date: " + DateTime.Now.ToString(), printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
            e.Graphics.DrawString("================================================================", printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
            e.Graphics.DrawString("Item Name                                 Quantity           Amount", printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
            e.Graphics.DrawString("================================================================", printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);

            foreach (DataGridViewRow row in guna2DataGridView1.Rows)
            {
                string itemName = row.Cells[3].Value.ToString().PadRight(40);
                string quantity = row.Cells[4].Value.ToString().PadRight(10);
                string amount = row.Cells[6].Value.ToString().PadRight(10);
                string line = itemName + quantity + amount;
                float lineHeight = printFont.GetHeight(e.Graphics);

                // Split the line into individual characters and print them one by one
                for (int i = 0; i < line.Length; i++)
                {
                    char c = line[i];
                    e.Graphics.DrawString(c.ToString(), printFont, Brushes.Black, leftMargin + (i * 8), yPos, new StringFormat());
                }

                yPos += lineHeight;
            }

            e.Graphics.DrawString("================================================================", printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
            e.Graphics.DrawString("Total: " + lbltotal1.Text, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
            e.Graphics.DrawString("Received: " + received.Text, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
            e.Graphics.DrawString("Change: " + txtchange.Text, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
            yPos += printFont.GetHeight(e.Graphics);
        }

        private void btnPrint_Click_1(object sender, EventArgs e)
        {
            PrintDocument doc = new PrintDocument();
            doc.PrintPage += new PrintPageEventHandler(doc_PrintPage);
            System.Windows.Forms.PrintDialog dlg = new System.Windows.Forms.PrintDialog();
            dlg.Document = doc;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                doc.Print();
            }
        }

        private void guna2DataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

